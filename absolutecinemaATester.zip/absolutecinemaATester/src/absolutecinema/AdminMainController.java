package absolutecinema;

import javafx.geometry.Pos;
import javafx.scene.text.Font;
import javafx.scene.layout.BorderPane;
import javafx.fxml.FXML;
import javafx.event.ActionEvent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.stage.Stage;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.layout.Region;
import javafx.scene.text.TextAlignment;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AdminMainController {
    @FXML private Button addButton;
    @FXML private HBox movieContainer;
    @FXML private Button shortcutbutton13;

    @FXML
    public void initialize() {
        loadMoviesFromDatabase();
    }
    
        @FXML
    public void handleStart(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/absolutecinema/AdminEditMovie.fxml")); 
            Parent root = loader.load();
            Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            System.err.println("Error loading AdminActualBooking.fxml: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    private void handleLogout(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/absolutecinema/WelcomeScreen.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
            System.out.println("Successfully logged out and returned to WelcomeScreen.");
        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Failed to load WelcomeScreen: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    public void loadMoviesFromDatabase() {
        String sql = "SELECT movie_id, movie_name, length, image_data FROM movies";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            movieContainer.getChildren().clear();
            movieContainer.setAlignment(Pos.TOP_LEFT);

            while (rs.next()) {
                int movieId = rs.getInt("movie_id"); // Fetch movie ID
                String titleText = rs.getString("movie_name");
                int duration = parseDuration(rs.getString("length"));
                byte[] imageBytes = rs.getBytes("image_data");

                // Create movie card
                VBox card = createMovieCard(movieId, titleText, duration, imageBytes);
                movieContainer.getChildren().add(card);
            }

        } catch (SQLException e) {
            showAlert("Database error: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    private int parseDuration(String durationText) {
        try {
            if (durationText.contains(":")) {
                String[] parts = durationText.split(":");
                int hours = Integer.parseInt(parts[0]);
                int minutes = Integer.parseInt(parts[1]);
                return (hours * 60) + minutes;
            }
            return Integer.parseInt(durationText);
        } catch (NumberFormatException e) {
            System.err.println("Invalid duration format: " + durationText);
            return 0;
        }
    }

    private VBox createMovieCard(int movieId, String titleText, int duration, byte[] imageBytes) {
        VBox card = new VBox(10);
        card.setPrefWidth(300);
        card.setStyle("-fx-background-color: black; -fx-padding: 10;");
        card.setAlignment(Pos.TOP_LEFT);

        // Gold frame for image
        BorderPane frame = new BorderPane();
        frame.setStyle("-fx-border-color: gold; -fx-border-width: 10; -fx-background-color: gold;");
        frame.setPrefSize(276, 338);
        frame.setMaxSize(Region.USE_PREF_SIZE, Region.USE_PREF_SIZE);

        ImageView imageView = new ImageView();
        imageView.setFitWidth(242);
        imageView.setFitHeight(313);
        imageView.setPreserveRatio(true);
        imageView.setImage(imageBytes != null ? new Image(new ByteArrayInputStream(imageBytes)) 
                                              : new Image("placeholder.png"));

        frame.setCenter(imageView);

        // Movie Title
        Label titleLabel = createLabel(titleText, 21);
        
        // Duration Label
        Label durationLabel = createLabel(duration + " mins", 21);

        // Edit Button
        Button editButton = createEditButton(movieId);

        // Assemble card
        card.getChildren().addAll(frame, titleLabel, durationLabel, editButton);
        return card;
    }

    private Label createLabel(String text, int fontSize) {
        Label label = new Label(text);
        label.setStyle("-fx-text-fill: white;");
        label.setFont(Font.font("Microsoft Sans Serif", fontSize));
        label.setWrapText(true);
        label.setMaxWidth(260);
        label.setAlignment(Pos.CENTER);
        label.setTextAlignment(TextAlignment.CENTER);
        return label;
    }

    private Button createEditButton(int movieId) {
        Button editButton = new Button("EDIT");
        editButton.setStyle("-fx-background-color: gold; -fx-text-fill: black; -fx-font-weight: bold;");
        editButton.setPrefWidth(100);

        editButton.setOnAction(e -> {
            System.out.println("Edit movie ID: " + movieId);

            try {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("/absolutecinema/AdminEditMovie.fxml"));
                Parent root = loader.load();

                // Get the controller and pass movie ID
                AdminEditMovieController controller = loader.getController();
                controller.setMovieId(movieId); // Pass the selected movie ID

                // Switch scenes
                Stage stage = (Stage) ((Button) e.getSource()).getScene().getWindow();
                stage.setScene(new Scene(root));
                stage.show();
            } catch (IOException f) {
                showAlert("Failed to load AdminEditMovie.fxml: " + f.getMessage(), Alert.AlertType.ERROR);
            }
        });

        return editButton;
    }

    private void showAlert(String message, Alert.AlertType type) {
        Alert alert = new Alert(type);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    @FXML
    private void handleAddMovie(ActionEvent event) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/absolutecinema/AdminActualBooking.fxml"));
            Parent root = loader.load();
            Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.show();
        } catch (IOException e) {
            System.err.println("Error loading AdminActualBooking.fxml: " + e.getMessage());
            showAlert("Failed to load AddMovie screen: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }
}
