/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package absolutecinema;

/**
 *
 * @author arlan
 */
public class Movie {
    private String title;
    private String synopsis;
    private String length;
    private String price;
    private String imagePath;

    public Movie(String title, String synopsis, String length, String price, String imagePath) {
        this.title = title;
        this.synopsis = synopsis;
        this.length = length;
        this.price = price;
        this.imagePath = imagePath;
    }

    public String getTitle() { return title; }
    public String getSynopsis() { return synopsis; }
    public String getLength() { return length; }
    public String getPrice() { return price; }
    public String getImagePath() { return imagePath; }

    @Override
    public String toString() {
        return title + " (" + length + ")";
    }
}