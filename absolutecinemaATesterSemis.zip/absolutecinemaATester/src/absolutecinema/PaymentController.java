package absolutecinema;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.layout.Region;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class PaymentController implements Initializable {

    private int bookingId;
    private double amount;

    public void setBookingDetails(int bookingId, double amount) {
        this.bookingId = bookingId;
        this.amount = amount;
    }

    @FXML
    private TextField nameF;

    @FXML
    private TextField emailF;

    @FXML
    private ComboBox<String> modPay;

    @FXML
    private Button cancelBtn;

    @FXML
    private Button confirmBtn;
    
    @FXML
     private TextField bookingPrice;
  
  

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Add payment options to ComboBox
        modPay.getItems().addAll("Credit Card", "Debit Card", "PayPal", "Gcash", "Your Soul");
        modPay.setPromptText("Select a payment method");
        modPay.setValue(null);
    }

    @FXML
    private void handleCancel() {
        // Confirmation dialog for cancel action
        Alert alert = new Alert(AlertType.CONFIRMATION);
        alert.setTitle("Cancel Payment");
        alert.setHeaderText(null);
        alert.setContentText("Are you sure you want to cancel the payment?");
        alert.getDialogPane().getStylesheets().add(getClass().getResource("payment.css").toExternalForm());
        alert.getDialogPane().getStyleClass().add("custom-alert");

        alert.showAndWait().ifPresent(response -> {
            if (response == ButtonType.OK) {
                // Clear input fields if confirmed
                nameF.clear();
                emailF.clear();
                modPay.setValue(null);
                try {
                    // Load the new FXML file
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("Main.fxml"));
                    Parent root = loader.load();

                    // Get the current stage and set the new scene
                    Stage stage = (Stage) cancelBtn.getScene().getWindow();
                    Scene scene = new Scene(root);
                    stage.setScene(scene);
                    stage.show();
                } catch (Exception e) {
                    System.err.println("Error occurred while loading Main.fxml: " + e.getMessage());
                    e.printStackTrace();
                }
            } else {
                System.out.println("Cancel action was canceled.");
            }
        });
    }

//Added by me
public void setAmount(String amountStr) {
    try {
        amountStr = amountStr.replace("Price:", "").replace("₱", "").trim(); // clean it
        this.amount = Double.parseDouble(amountStr);
        bookingPrice.setText("₱" + amountStr); // update field if needed
    } catch (NumberFormatException e) {
        System.err.println("Invalid amount format: " + amountStr);
    }
}

  @FXML
private void handleConfirm() {
    String name = nameF.getText();
    String email = emailF.getText();
    String payment_method = modPay.getValue();
    String payment_date = java.time.LocalDate.now().toString();
    String payment_time = java.time.LocalTime.now().toString();

    if (name.isEmpty() || email.isEmpty() || payment_method == null || payment_method.trim().isEmpty()) {
        Alert alert = new Alert(AlertType.WARNING);
        alert.setTitle("Incomplete Form");
        alert.setHeaderText(null);
        alert.setContentText("Please fill in all fields.");
        alert.showAndWait();
        return;
    }

    try {
        Connection conn = DBConnection.getConnection();
        if (conn != null) {
            String sql = "INSERT INTO payments (name, email, payment_method, payment_date, payment_time) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);

            stmt.setString(1, name);
            stmt.setString(2, email);
            stmt.setString(3, payment_method);
            stmt.setString(4, payment_date);
            stmt.setString(5, payment_time);

            int rowsInserted = stmt.executeUpdate();

            if (rowsInserted > 0) {
                Alert alert = new Alert(AlertType.INFORMATION);
                alert.setTitle("Payment Confirmed!");
                alert.setHeaderText("Thank you for your payment!");
                alert.setContentText("Name: " + name + "\nEmail: " + email + "\nPayment Method: " + payment_method);
                alert.getDialogPane().getStylesheets().add(getClass().getResource("payment.css").toExternalForm());
                alert.getDialogPane().getStyleClass().add("custom-alert");
                alert.showAndWait();

                FXMLLoader loader = new FXMLLoader(getClass().getResource("Main.fxml"));
                Parent root = loader.load();
                Stage stage = (Stage) confirmBtn.getScene().getWindow();
                stage.setScene(new Scene(root));
                stage.show();
            }

            stmt.close();
            conn.close();
        }
    } catch (Exception e) {
        System.err.println("Error occurred while saving payment: " + e.getMessage());
        e.printStackTrace();
    }
}


    public void showCustomAlert() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION, "This is a custom alert box!", ButtonType.OK);
        alert.setTitle("Custom Alert");
        alert.setHeaderText("Custom Header");

        // Set a custom size for the alert
        alert.getDialogPane().setMinHeight(Region.USE_PREF_SIZE);
        alert.getDialogPane().setMinWidth(400); // Adjust the width

        // Add CSS styles (optional)
        alert.getDialogPane().getStylesheets().add(getClass().getResource("custom.css").toExternalForm());
        alert.getDialogPane().getStyleClass().add("custom-alert");

        alert.showAndWait();
    }

}
